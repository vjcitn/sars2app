sars2app -- thinned out sars2pack for sake of shinyapps.io covidTS app
