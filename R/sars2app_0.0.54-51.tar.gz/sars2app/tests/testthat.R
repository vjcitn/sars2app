library(testthat)
library(sars2app)

test_check("sars2app")
